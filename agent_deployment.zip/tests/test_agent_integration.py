import unittest
import threading
import time
import requests
import os
from unittest.mock import MagicMock, patch
from orca_agent_sdk.agent import OrcaAgent

# We need to run the agent in a separate thread
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agent import main as agent_main

# Global flag to stop server if needed (not easily doable with basic Flask/server run, 
# so we might just kill the thread or rely on daemon=True)

class TestAgentIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Set dummy env vars for the agent
        os.environ["AGENT_VAULT"] = "0x" + "1"*40
        os.environ["GOOGLE_API_KEY"] = "mock_key"
        os.environ["PORT"] = "8001" # verification port
        
    def setUp(self):
        # Mock WalletManager to avoid missing file errors
        self.wallet_patcher = patch('orca_agent_sdk.agent.AgentWalletManager')
        self.MockWalletManager = self.wallet_patcher.start()
        self.MockWalletManager.return_value._private_key = "0x0000000000000000000000000000000000000000000000000000000000000001"

        # Mock the OrcaAgentVaultClient
        self.vault_patcher = patch('orca_agent_sdk.agent.OrcaAgentVaultClient')
        self.MockVaultClient = self.vault_patcher.start()
        
        # Setup the mock instance
        self.mock_vault_instance = self.MockVaultClient.return_value
        self.mock_vault_instance.spend.return_value = "0xmocktxhash"
        self.mock_vault_instance.get_balance.return_value = 1000000 # 1 USDC

        # Start the agent in a background thread
        # Note: server.run() is blocking. We'll run it in a thread.
        # We need to ensure we don't start it multiple times if using setUpClass, 
        # but here we do it per test or class? 
        # Ideally per class, but `agent.run` might not be stoppable easily.
        # Let's try to start it once.
        pass

    def tearDown(self):
        self.vault_patcher.stop()
        self.wallet_patcher.stop()

    @patch('orca_agent_sdk.server.AgentServer.run') # Mock run to avoid blocking, BUT we want it to handle request...
    def test_agent_initialization(self, mock_run):
        # This just tests if it initializes correctly
        from agent import main
        # We assume main calls agent.run()
        main()
        self.assertTrue(self.MockVaultClient.called)
        self.assertEqual(len(self.MockVaultClient.call_args_list), 1)

    # Real integration test needs the server running. 
    # Since we can't easily kill the Flask/server in this environment without complex logic,
    # We will simulate the "Handler" logic directly if possible, OR
    # We assume 'agent.run' starts a server we can hit if we put it in a thread.
    # But stopping it is hard.
    # Alternative: We test the `handle_prompt` or internal logic if exposed.
    # `OrcaAgent` relies on `AgentServer`.
    
    # Let's mock the `requests.post` to the LLM backend if we want to test that too,
    # but primarily we want to test that `spend` is called.

    def test_claim_payment_logic(self):
        # Instantiate agent directly
        agent = OrcaAgent(
            name="TestAgent",
            model="gemini/mock",
            system_prompt="test",
            price="0.1",
            vault_address="0x123"
        )
        
        # Simulate payment
        tx = agent.claim_payment("0xtaskid", 0.1)
        
        # Check if our MockVaultClient (which is set on agent.vault_client) was used
        self.mock_vault_instance.spend.assert_called_with("0xtaskid", 100000) # 0.1 * 10^6
        self.assertEqual(tx, "0xmocktxhash")

if __name__ == "__main__":
    unittest.main()
