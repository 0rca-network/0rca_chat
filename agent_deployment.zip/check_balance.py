from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

RPC_URL = "https://evm-t3.cronos.org"
import json

def check_balance():
    w3 = Web3(Web3.HTTPProvider(RPC_URL))
    w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)
    
    address = "0x975C5b75Ff1141E10c4f28454849894F766B945E"
    
    balance = w3.eth.get_balance(address)
    print(f"Address: {address}")
    print(f"TCRO Balance: {w3.from_wei(balance, 'ether')}")
    
    # Check USDC too
    USDC_ADDRESS = "0x38Bf87D7281A2F84c8ed5aF1410295f7BD4E20a1"
    abi = [{"constant":True,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":False,"stateMutability":"view","type":"function"}]
    contract = w3.eth.contract(address=USDC_ADDRESS, abi=abi)
    usdc_bal = contract.functions.balanceOf(address).call()
    print(f"USDC Balance: {usdc_bal / 10**6}")

if __name__ == "__main__":
    check_balance()
