import os
import sys
from dotenv import load_dotenv
from orca_agent_sdk.agent import OrcaAgent

# Load environment variables
load_dotenv()

def main():
    # Helper to check required env vars
    api_key = os.getenv("GOOGLE_API_KEY")
    model = "gemini/gemini-2.0-flash"
    
    if not api_key:
        api_key = os.getenv("MISTRAL_API_KEY")
        if api_key:
            model = "mistral/mistral-large-latest" # Example model
    
    if not api_key:
        print("Error: Missing GOOGLE_API_KEY or MISTRAL_API_KEY.")
        sys.exit(1)
        
    vault_address = os.getenv("AGENT_VAULT")
    if not vault_address:
         print("Error: Missing AGENT_VAULT.")
         sys.exit(1)

    # Initialize the Sovereign Agent
    agent = OrcaAgent(
        name="StarterAgent-001",
        model=model,
        system_prompt="You are a sovereign agent ready to perform tasks and earn USDC.",
        price="0.1", # Price per request
        vault_address=vault_address,
        api_key=api_key
    )

    print(f"[{agent.name}] Initialized with Vault: {agent.vault_address}")
    
    # Start the Server
    # Defaults to port 8000
    port = int(os.getenv("PORT", 8000))
    agent.run(port=port)

if __name__ == "__main__":
    main()
