import os
import sys
from dotenv import load_dotenv
from orca_agent_sdk.agent import OrcaAgent

# Load environment variables
load_dotenv()

def main():
    # Helper to check required env vars
    api_key = os.getenv("GOOGLE_API_KEY")
    model = "gemini/gemini-2.0-flash"
    
    if not api_key:
        api_key = os.getenv("MISTRAL_API_KEY")
        if api_key:
            model = "mistral/mistral-large-latest" 
    
    if not api_key:
        print("Error: Missing GOOGLE_API_KEY or MISTRAL_API_KEY.")
        sys.exit(1)
        
    vault_address = os.getenv("AGENT_VAULT")
    if not vault_address:
         print("Error: Missing AGENT_VAULT.")
         sys.exit(1)

    # Initialize the Security Auditor Agent
    agent = OrcaAgent(
        name="SecurityAuditor",
        model=model,
        system_prompt="You are a specialized Security Auditor agent. Your goal is to analyze smart contracts and system architectures for vulnerabilities. You are thorough, paranoid, and technical.",
        price="0.1", 
        vault_address=vault_address,
        api_key=api_key
    )

    print(f"[{agent.name}] Initialized with Vault: {agent.vault_address}")
    
    # Start the Server on Port 8002
    port = 8002
    agent.run(port=port)

if __name__ == "__main__":
    main()
