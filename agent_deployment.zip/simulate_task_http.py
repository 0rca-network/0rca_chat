import requests
import json
import secrets
import time

AGENT_URL = "http://localhost:8000/agent"

def simulate_http_only():
    # Generate a fake task ID
    task_id = "0x" + secrets.token_hex(32)
    print(f"Generated Task ID: {task_id}")
    
    # Headers - attempting to use the bypass mentioned in the reference code
    # If the agent doesn't accept this, it might return 402, which is also a valid test result (connection working)
    headers = {
        "Content-Type": "application/json",
        "X-TEST-BYPASS": "true"
    }
    
    payload = {
        "prompt": "Analyze the security of my vault contract.",
        "taskId": task_id
    }
    
    print(f"Sending request to {AGENT_URL}...")
    try:
        resp = requests.post(AGENT_URL, json=payload, headers=headers)
        print(f"Response Status: {resp.status_code}")
        try:
            print("Response Body:", json.dumps(resp.json(), indent=2))
        except:
            print("Response Body (Text):", resp.text)
            
    except Exception as e:
        print(f"Request failed: {e}")

if __name__ == "__main__":
    simulate_http_only()
