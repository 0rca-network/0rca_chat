import requests
import os
import json
import secrets
import time
from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

# CONFIG
AGENT_URL = "http://localhost:8000/agent"
RPC_URL = "https://evm-t3.cronos.org"
USDC_TOKEN = "0x38Bf87D7281A2F84c8ed5aF1410295f7BD4E20a1"
VAULT_ADDRESS = "0xe7bad567ed213efE7Dd1c31DF554461271356F30" # User provided
PRIVATE_KEY = "63918bb7d149f6cc03b40aeff33aff6da1736a1fe1f479f0da95e694698f69dc" # From SDK file

def simulate_real():
    print(f"--- Starting Real On-Chain Simulation ---")
    
    # 1. Setup Wallet
    w3 = Web3(Web3.HTTPProvider(RPC_URL))
    w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)
    account = w3.eth.account.from_key(PRIVATE_KEY)
    print(f"Client Address: {account.address}")
    
    # 2. Approve USDC
    usdc_abi = [{"inputs": [{"name": "spender", "type": "address"}, {"name": "amount", "type": "uint256"}], "name": "approve", "outputs": [{"name": "", "type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
                {"inputs": [{"name": "owner", "type": "address"}, {"name": "spender", "type": "address"}], "name": "allowance", "outputs": [{"name": "", "type": "uint256"}], "stateMutability": "view", "type": "function"}]
    
    usdc = w3.eth.contract(address=USDC_TOKEN, abi=usdc_abi)
    amount = 100000 # 0.1 USDC
    
    allowance = usdc.functions.allowance(account.address, VAULT_ADDRESS).call()
    print(f"Allowance: {allowance}")
    
    if allowance < amount:
        print(f"Approving USDC...")
        nonce = w3.eth.get_transaction_count(account.address)
        tx = usdc.functions.approve(VAULT_ADDRESS, amount * 100).build_transaction({
            'chainId': 338, 'gas': 100000, 'gasPrice': w3.eth.gas_price, 'nonce': nonce
        })
        signed_tx = w3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"Approval Tx: {w3.to_hex(tx_hash)}")
        w3.eth.wait_for_transaction_receipt(tx_hash)
    
    # 3. Create Task
    task_id_raw = secrets.token_hex(32)
    task_id = "0x" + task_id_raw
    print(f"Creating Task ID: {task_id}")
    
    # Need Vault ABI - minimalistic
    vault_abi = [
        {"inputs": [{"internalType": "bytes32", "name": "taskId", "type": "bytes32"}, {"internalType": "uint256", "name": "amount", "type": "uint256"}], "name": "createTask", "outputs": [], "stateMutability": "nonpayable", "type": "function"}
    ]
    
    vault = w3.eth.contract(address=VAULT_ADDRESS, abi=vault_abi)
    
    nonce = w3.eth.get_transaction_count(account.address)
    print("Sending createTask tx...")
    tx = vault.functions.createTask(
        bytes.fromhex(task_id_raw),
        amount
    ).build_transaction({
        'chainId': 338, 'gas': 300000, 'gasPrice': w3.eth.gas_price, 'nonce': nonce
    })
    
    signed_tx = w3.eth.account.sign_transaction(tx, PRIVATE_KEY)
    tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
    print(f"CreateTask Tx: {w3.to_hex(tx_hash)}")
    
    # Wait for confirmation
    print("Waiting for confirmation...")
    w3.eth.wait_for_transaction_receipt(tx_hash)
    print("Task confirmed!")
    
    # 4. Call Agent (REAL)
    print("Calling Agent...")
    payload = {
        "prompt": "Simulated paid task from User.",
        "taskId": task_id
    }
    
    try:
        # Pass the Task ID so Agent executes spend()
        # Pass X-TEST-BYPASS so we skip the EIP-712 signature check (ingress), 
        # but the Agent will still try to SPEND on-chain (egress) if logic permits.
        headers = {
            "X-TASK-ID": task_id,
            "X-TEST-BYPASS": "true"
        }
        resp = requests.post(AGENT_URL, json=payload, headers=headers)
        print(f"Agent Status: {resp.status_code}")
        print(f"Agent Body: {resp.text}")
    except Exception as e:
        print(f"Error calling agent: {e}")

if __name__ == "__main__":
    simulate_real()
